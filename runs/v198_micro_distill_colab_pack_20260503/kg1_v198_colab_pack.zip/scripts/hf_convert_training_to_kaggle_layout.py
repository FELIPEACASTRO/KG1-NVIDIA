#!/usr/bin/env python3
"""Convert a trained HF-layout Nemotron adapter back to Kaggle layout.

The confirmed 0.86 submission uses ``base_model.model.model.*`` layer keys and
``base_model.model.lm_head.*`` unembedding keys. For HF training we converted
the baseline to ``base_model.model.backbone.*`` so PEFT could load it into the
public Transformers model. This script reverses both namespaces, writes a
baseline-compatible adapter_config.json, and packages a root-only Kaggle ZIP.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from huggingface_hub import HfApi, hf_hub_download
from safetensors import safe_open
from safetensors.torch import save_file


def env_str(name: str, default: str) -> str:
    return os.environ.get(name, default).strip()


SOURCE_REPO = env_str("SOURCE_REPO", "felipesp1983/kg1-nemotron-lora-v87-delta")
SOURCE_SUBFOLDER = env_str("SOURCE_SUBFOLDER", "final_stripped")
DEST_REPO = env_str("DEST_REPO", SOURCE_REPO)
DEST_SUBFOLDER = env_str("DEST_SUBFOLDER", "final_kaggle_layout")
ZIP_SUBFOLDER = env_str("ZIP_SUBFOLDER", "submissions")
RUN_ID = env_str("RUN_ID", "v087-delta-canonical086-safeoom-lr1e5-s80-kaggle-layout")
WORK_DIR = Path(env_str("WORK_DIR", "/tmp/kg1_kaggle_layout"))
HF_TOKEN = os.environ.get("HF_TOKEN") or ""

TRAINING_PREFIX = "base_model.model.backbone."
TRAINING_LM_HEAD_PREFIX = "base_model.model.backbone.lm_head."
KAGGLE_PREFIX = "base_model.model.model."
KAGGLE_LM_HEAD_PREFIX = "base_model.model.lm_head."


CANONICAL_ADAPTER_CONFIG = {
    "peft_type": "LORA",
    "auto_mapping": None,
    "base_model_name_or_path": "nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B-BF16",
    "bias": "none",
    "fan_in_fan_out": False,
    "inference_mode": True,
    "init_lora_weights": True,
    "lora_alpha": 32,
    "lora_dropout": 0.0,
    "modules_to_save": None,
    "r": 32,
    "rank_pattern": {"in_proj": 32},
    "alpha_pattern": {"in_proj": 32},
    "target_modules": [
        "down_proj",
        "in_proj",
        "k_proj",
        "lm_head",
        "o_proj",
        "out_proj",
        "q_proj",
        "up_proj",
        "v_proj",
    ],
    "task_type": "CAUSAL_LM",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main() -> int:
    if not HF_TOKEN:
        raise RuntimeError("HF_TOKEN is required for private repos.")

    raw_dir = WORK_DIR / "raw" / SOURCE_SUBFOLDER
    out_dir = WORK_DIR / "out" / DEST_SUBFOLDER
    zip_dir = WORK_DIR / "zip"
    for directory in (raw_dir, out_dir, zip_dir):
        directory.mkdir(parents=True, exist_ok=True)

    print(f"Source repo: {SOURCE_REPO}/{SOURCE_SUBFOLDER}")
    print(f"Destination repo: {DEST_REPO}/{DEST_SUBFOLDER}")

    weights_src = Path(
        hf_hub_download(
            repo_id=SOURCE_REPO,
            repo_type="model",
            filename=f"{SOURCE_SUBFOLDER}/adapter_model.safetensors",
            token=HF_TOKEN,
            local_dir=str(WORK_DIR / "download"),
        )
    )
    manifest_src = Path(
        hf_hub_download(
            repo_id=SOURCE_REPO,
            repo_type="model",
            filename=f"{SOURCE_SUBFOLDER}/strip_package_report.json",
            token=HF_TOKEN,
            local_dir=str(WORK_DIR / "download"),
        )
    )

    weights_path = raw_dir / "adapter_model.safetensors"
    shutil.copyfile(weights_src, weights_path)

    converted: dict[str, Any] = {}
    renamed_count = 0
    unchanged_count = 0
    unexpected_prefix_sample: list[str] = []
    with safe_open(str(weights_path), framework="pt", device="cpu") as handle:
        for key in handle.keys():
            tensor = handle.get_tensor(key)
            if key.startswith(TRAINING_LM_HEAD_PREFIX):
                new_key = KAGGLE_LM_HEAD_PREFIX + key[len(TRAINING_LM_HEAD_PREFIX):]
                renamed_count += 1
            elif key.startswith(TRAINING_PREFIX):
                new_key = KAGGLE_PREFIX + key[len(TRAINING_PREFIX):]
                renamed_count += 1
            else:
                new_key = key
                unchanged_count += 1
                if not key.startswith("base_model.model.lm_head."):
                    unexpected_prefix_sample.append(key)
            converted[new_key] = tensor

    out_weights = out_dir / "adapter_model.safetensors"
    save_file(converted, str(out_weights))
    write_json(out_dir / "adapter_config.json", CANONICAL_ADAPTER_CONFIG)

    zip_path = zip_dir / f"{RUN_ID}_adapter_only.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.write(out_dir / "adapter_config.json", "adapter_config.json")
        archive.write(out_weights, "adapter_model.safetensors")

    report = {
        "generated_at": utc_now(),
        "run_id": RUN_ID,
        "source_repo": SOURCE_REPO,
        "source_subfolder": SOURCE_SUBFOLDER,
        "dest_repo": DEST_REPO,
        "dest_subfolder": DEST_SUBFOLDER,
        "input": {
            "adapter_model_bytes": weights_path.stat().st_size,
            "adapter_model_sha256": sha256_file(weights_path),
            "strip_report_sha256": sha256_file(manifest_src),
        },
        "output": {
            "adapter_model_bytes": out_weights.stat().st_size,
            "adapter_model_sha256": sha256_file(out_weights),
            "zip_bytes": zip_path.stat().st_size,
            "zip_sha256": sha256_file(zip_path),
            "tensor_count": len(converted),
            "renamed_backbone_to_model_count": renamed_count,
            "unchanged_count": unchanged_count,
            "unexpected_unchanged_prefix_sample": unexpected_prefix_sample[:20],
        },
        "decision": {
            "kaggle_layout_ready": renamed_count > 0 and not unexpected_prefix_sample,
            "note": "Kaggle upload still requires explicit user authorization.",
        },
    }
    report_path = out_dir / "kaggle_layout_report.json"
    write_json(report_path, report)
    print(json.dumps(report, indent=2, sort_keys=True))

    api = HfApi(token=HF_TOKEN)
    api.create_repo(DEST_REPO, repo_type="model", private=True, exist_ok=True)
    api.upload_folder(
        repo_id=DEST_REPO,
        repo_type="model",
        folder_path=str(out_dir),
        path_in_repo=DEST_SUBFOLDER,
        token=HF_TOKEN,
        commit_message=f"{RUN_ID} Kaggle layout adapter",
    )
    api.upload_file(
        repo_id=DEST_REPO,
        repo_type="model",
        path_or_fileobj=str(zip_path),
        path_in_repo=f"{ZIP_SUBFOLDER}/{zip_path.name}",
        token=HF_TOKEN,
        commit_message=f"{RUN_ID} Kaggle layout submission zip",
    )
    print(f"Uploaded Kaggle-layout adapter and zip to {DEST_REPO}.")
    return 0 if report["decision"]["kaggle_layout_ready"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
