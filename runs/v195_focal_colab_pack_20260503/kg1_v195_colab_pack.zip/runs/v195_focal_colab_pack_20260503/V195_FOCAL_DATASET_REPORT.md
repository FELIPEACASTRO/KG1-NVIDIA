# V195 focal Colab dataset

Train rows: 3903
Validation rows: 720

## Train families

- bit_manipulation: 1634
- equation_transform: 940
- gravity_constant: 549
- numeral_system: 260
- text_encryption: 260
- unit_conversion: 260

## Sources

- v195_official_selector_solver: 1261
- v195_v90_gold_safe_rehearsal: 960
- v195_v94_equation_crypt: 782
- v195_v95_bit_rehearsal: 900

## Stage additions

- official_selector_solver: 1261
- v94_equation_transform: 782
- v95_bit_manipulation_cap: 900
- v90_stable_rehearsal: 960

## Validation overlap drops

- official_selector_solver: 106
- v94_equation_crypt: 0
- v95_bit_rehearsal: 0
- v90_gold_safe: 720

## Gate

Training notebook uses v195_focal_train.strict.jsonl.
Regenerate the pack after running kg1_training_data_gate.py and filtering format issues.
