# V195 next actions

Status: dataset and Colab pack are ready. No Kaggle submission was created.

## Why this route

V193 and V194 both scored 0.86. The attention-only soup did not regress, but it also did not move the public score. The next rational route is a short focal SFT that teaches the adapter the verified offline solver patterns instead of submitting more nearby soup weights.

## Artifacts

- Pack: `runs/v195_focal_colab_pack_20260503/kg1_v195_colab_pack.zip`
- Notebook: `notebooks/KG1_V195_FOCAL_COLAB_PRO.ipynb`
- Strict training JSONL: `data/v195/v195_focal_train.strict.jsonl`
- Validation JSONL: `data/v195/v195_focal_val.jsonl`
- Baseline adapter to initialize from: `runs/roadmap_087_20260501/aaitdads_0p86_hf_stage/final`

## Gates already passed

- Training data gate strict: valid, 3798 rows, boxed rate 1.0, no test overlap.
- SFT format validator strict: clean rate 1.0.
- Notebook JSON: valid.
- Pack contains strict dataset, train script, local converter, and notebook.

## Train recipe

- Initialize from the 0.86 aaitdads HF-layout adapter.
- Train only lighter LoRA modules: `in_proj,out_proj,q_proj,k_proj,v_proj,o_proj`.
- Keep experts and lm_head frozen during this focal run.
- Use 110 steps first, LR `4e-5`, max length 2048.
- Convert the resulting `final_adapter` locally to Kaggle layout with `kg1_convert_local_training_adapter_to_kaggle_zip.py`.

## Submit gate

Do not submit the converted ZIP unless:

- local adapter layout conversion report says `kaggle_layout_ready=true`;
- inference/prescore does not regress the stable families;
- validation beats V193/V194 baseline, ideally with equation_transform gain and no bit/text/gravity loss.
