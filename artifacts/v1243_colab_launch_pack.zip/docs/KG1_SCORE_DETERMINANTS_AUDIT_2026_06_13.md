# KG1 Score Determinants Audit

Este documento registra os determinantes que precisam estar alinhados para um
job de treino ter chance real de virar score no Kaggle. Loss isolado nao e
score.

Itens bloqueantes validados pelo caminho V1243:

- Datasets corretos por hash: bit, equation, micro_consolidation e val170.
- Separacao sem leak contra val170 e full947 canonico.
- Respostas finais com exatamente um `\boxed{...}` terminal.
- Offset mask e boxed payload weighting ativos em 100% das linhas.
- LoRA rank/alpha/target modules compativeis com contrato Kaggle.
- Adapter inicial V291/086 fixado por repo, revision e hashes.
- Score proxy por familia/classe em val170 antes, durante e depois do treino.
- `SCORE_TRAJECTORY` habilitado: bit/equation precisam melhorar sem regressao
  global/protegida.
- No notebook final sprint, `REQUIRE_SCORE_TRAJECTORY_PASS=1` com
  `REQUIRE_SCORE_TRAJECTORY_FINAL_ONLY=1`, para nao abortar por ruido cedo e
  bloquear candidato final sem trajetoria OK.
- Claim de score so pode vir apos comparacao full947/raw_output pelo gate
  V1241; nenhum log de treino substitui essa prova.

