# Colab Real-Time Log Monitoring

Use este guia para interpretar os logs do launcher V1243 no Colab.

Sinais obrigatorios de saude:

- `KG1_V1243_COLAB_LAUNCH_ENV_BEGIN/END`: confirma fase, dataset, hashes,
  upload HF e overrides usados no job.
- `KG1_SCORE_CONTRACT_STATUS=OK`: confirma LoRA rank/target modules,
  adapter inicial, truncation guard, mask e contrato de score.
- `KG1_SCORE_PROXY_STATUS=...`: mostra loss, boxed_tail_loss,
  boxed_tail_token_acc e boxed_tail_exact_rate. Loss sozinho nao decide.
- `KG1_SCORE_PROXY_FAMILY_STATUS=...`: mostra a saude por familia.
- `KG1_SCORE_TRAJECTORY_STATUS=...`: mede se bit/equation estao andando para
  frente sem regressao global/protegida.
- `KG1_LIVE_UPLOAD_OK`: confirma que `train.log` e `status.json` foram
  enviados para HF em tempo real.

Regra operacional do final sprint:

- Evals intermediarios podem ficar em `WATCH`/`RISK`; isso serve como alerta.
- O candidato final precisa terminar com score trajectory OK quando
  `REQUIRE_SCORE_TRAJECTORY_PASS=1` e
  `REQUIRE_SCORE_TRAJECTORY_FINAL_ONLY=1`.
- Nenhum log de treino substitui o gate full947/raw_output antes de claim de
  score Kaggle.

