#!/usr/bin/env python3
"""Colab-safe launcher for V1243 KG1 bit/equation specialist jobs."""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ARTIFACT_DIR = ROOT / "artifacts" / "v1243_solver_to_lora_graft"
ENV_PREVIEW = DEFAULT_ARTIFACT_DIR / "v1243_hf_env_preview.json"
SAFE_PHASES = {"bit_specialist", "equation_specialist"}
RUN_MODES = {"tokenize_dryrun", "model_dryrun", "real_train"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=sorted(SAFE_PHASES), default="bit_specialist")
    parser.add_argument("--run-mode", choices=sorted(RUN_MODES), default="tokenize_dryrun")
    parser.add_argument("--artifact-dir", type=Path, default=DEFAULT_ARTIFACT_DIR)
    parser.add_argument("--env-preview", type=Path, default=ENV_PREVIEW)
    parser.add_argument("--run-id", default="")
    parser.add_argument("--target-accuracy", type=float, default=float(os.environ.get("KG1_TARGET_ACCURACY", "0.89")))
    parser.add_argument("--live-log-repo", default=os.environ.get("KG1_LIVE_LOG_HF_REPO", ""))
    parser.add_argument("--live-log-repo-type", default=os.environ.get("KG1_LIVE_LOG_HF_REPO_TYPE", "dataset"))
    parser.add_argument("--upload-every", type=float, default=float(os.environ.get("KG1_LIVE_LOG_UPLOAD_EVERY", "60")))
    parser.add_argument("--min-gpu-total-gib", type=float, default=float(os.environ.get("KG1_MIN_GPU_TOTAL_GIB", "70")))
    parser.add_argument("--min-disk-free-gib", type=float, default=float(os.environ.get("KG1_MIN_CONTENT_FREE_GIB", "35")))
    parser.add_argument("--accept-gpu-spend", action="store_true", default=os.environ.get("KG1_ACCEPT_GPU_SPEND", "0") == "1")
    parser.add_argument(
        "--require-live-log-upload",
        action="store_true",
        default=os.environ.get("KG1_REQUIRE_LIVE_LOG_UPLOAD", "0") == "1",
    )
    parser.add_argument("--init-adapter-dir", default=os.environ.get("INIT_ADAPTER_DIR", ""))
    parser.add_argument("--init-adapter-repo", default=os.environ.get("INIT_ADAPTER_REPO", ""))
    parser.add_argument("--init-adapter-revision", default=os.environ.get("INIT_ADAPTER_REVISION", ""))
    parser.add_argument("--init-adapter-subfolder", default=os.environ.get("INIT_ADAPTER_SUBFOLDER", ""))
    parser.add_argument("--require-init-adapter", action="store_true", default=os.environ.get("REQUIRE_INIT_ADAPTER", "0") == "1")
    parser.add_argument(
        "--require-init-adapter-revision",
        action="store_true",
        default=os.environ.get("REQUIRE_INIT_ADAPTER_REVISION", "0") == "1",
    )
    parser.add_argument("--output-repo", default=os.environ.get("OUTPUT_REPO", ""))
    parser.add_argument("--allow-real-train", action="store_true")
    parser.add_argument("--print-env-only", action="store_true")
    return parser


def load_env_preview(path: Path, phase: str) -> dict[str, str]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    env = payload.get(phase)
    if not isinstance(env, dict):
        raise KeyError(f"phase not found in env preview: {phase}")
    return {str(key): str(value) for key, value in env.items()}


def colab_default_output_dir(run_id: str) -> str:
    if Path("/content").exists():
        return f"/content/kg1_outputs/{run_id}"
    return str(ROOT / "artifacts" / "v1243_colab_local_outputs" / run_id)


def localize_dataset_path(artifact_dir: Path, value: str) -> str:
    name = Path(value.replace("\\", "/")).name
    path = artifact_dir / name
    if not path.exists():
        raise FileNotFoundError(f"required V1243 artifact missing: {path}")
    return str(path)


def apply_run_mode(env: dict[str, str], args: argparse.Namespace) -> None:
    if args.run_mode == "tokenize_dryrun":
        env["DRY_RUN_VALIDATE_ONLY"] = "1"
        env["TOKENIZE_ONLY_DRY_RUN"] = "1"
        env["UPLOAD_TO_HF"] = "0"
    elif args.run_mode == "model_dryrun":
        env["DRY_RUN_VALIDATE_ONLY"] = "1"
        env["TOKENIZE_ONLY_DRY_RUN"] = "0"
        env["UPLOAD_TO_HF"] = "0"
    elif args.run_mode == "real_train":
        if not args.allow_real_train:
            raise RuntimeError("real_train requires --allow-real-train")
        if not args.output_repo:
            raise RuntimeError("real_train requires --output-repo so final adapter is not stranded in Colab")
        env["DRY_RUN_VALIDATE_ONLY"] = "0"
        env["TOKENIZE_ONLY_DRY_RUN"] = "0"
        env["UPLOAD_TO_HF"] = "1"
        env["OUTPUT_REPO"] = args.output_repo
    else:
        raise ValueError(f"unknown run mode: {args.run_mode}")


def build_env(args: argparse.Namespace) -> tuple[dict[str, str], str]:
    artifact_dir = args.artifact_dir.resolve()
    env = load_env_preview(args.env_preview.resolve(), args.phase)
    run_id = args.run_id or os.environ.get("RUN_ID") or f"v1243_{args.phase}_{args.run_mode}_{time.strftime('%Y%m%d_%H%M%S')}"

    env["RUN_ID"] = run_id
    env["DATA_FILE"] = localize_dataset_path(artifact_dir, env["DATA_FILE"])
    env["VAL_FILE"] = localize_dataset_path(artifact_dir, env["VAL_FILE"])
    env["DATA_REPO"] = "local-v1243-colab-launch"
    env["OUTPUT_DIR"] = colab_default_output_dir(run_id)
    env["COMPUTE_PROVIDER"] = "colab_pro_v1243_realtime"
    env["SCORE_CONTRACT_TARGET_ACCURACY"] = str(args.target_accuracy)
    env["FRIENDLY_REALTIME_LOGS"] = "1"
    env["FRIENDLY_LOG_SCORE_HINTS"] = "1"
    env["PYTHONUNBUFFERED"] = "1"
    env["HF_HUB_ENABLE_HF_TRANSFER"] = "1"
    env["TOKENIZERS_PARALLELISM"] = "false"
    env["KG1_LIVE_LOG_UPLOAD_EVERY"] = str(args.upload_every)
    env["KG1_REQUIRE_LIVE_LOG_UPLOAD"] = "1" if args.require_live_log_upload else "0"
    env["KG1_ACCEPT_GPU_SPEND"] = "1" if args.accept_gpu_spend else "0"

    if args.live_log_repo:
        env["KG1_LIVE_LOG_HF_REPO"] = args.live_log_repo
        env["KG1_LIVE_LOG_HF_REPO_TYPE"] = args.live_log_repo_type
        env["KG1_LIVE_LOG_HF_PATH"] = f"colab/{run_id}/train.log"
        env["KG1_LIVE_STATUS_HF_PATH"] = f"colab/{run_id}/status.json"

    if args.init_adapter_dir:
        env["INIT_ADAPTER_DIR"] = args.init_adapter_dir
    if args.init_adapter_repo:
        env["INIT_ADAPTER_REPO"] = args.init_adapter_repo
    if args.init_adapter_revision:
        env["INIT_ADAPTER_REVISION"] = args.init_adapter_revision
    if args.init_adapter_subfolder:
        env["INIT_ADAPTER_SUBFOLDER"] = args.init_adapter_subfolder
    if args.require_init_adapter:
        env["REQUIRE_INIT_ADAPTER"] = "1"
    if args.require_init_adapter_revision:
        env["REQUIRE_INIT_ADAPTER_REVISION"] = "1"

    apply_run_mode(env, args)
    return env, run_id


def is_truthy(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "y", "on"}


def adapter_weight_exists(path: Path) -> bool:
    return (path / "adapter_model.safetensors").exists() or (path / "adapter_model.bin").exists()


def validate_initial_adapter_contract(env: dict[str, str], args: argparse.Namespace) -> None:
    if args.run_mode == "tokenize_dryrun":
        return
    require_init = args.require_init_adapter or is_truthy(env.get("REQUIRE_INIT_ADAPTER"))
    if not require_init:
        return
    init_dir = env.get("INIT_ADAPTER_DIR", "")
    init_repo = env.get("INIT_ADAPTER_REPO", "")
    init_revision = env.get("INIT_ADAPTER_REVISION", "")
    if not init_dir and not init_repo:
        raise RuntimeError(
            "V1243 model_dryrun/real_train requires a baseline initial adapter. "
            "Set INIT_ADAPTER_DIR or INIT_ADAPTER_REPO before spending GPU."
        )
    if init_dir:
        adapter_dir = Path(init_dir)
        if not adapter_dir.exists():
            raise FileNotFoundError(f"INIT_ADAPTER_DIR not found: {adapter_dir}")
        if not (adapter_dir / "adapter_config.json").exists() or not adapter_weight_exists(adapter_dir):
            raise RuntimeError(f"INIT_ADAPTER_DIR is not a complete PEFT adapter directory: {adapter_dir}")
    if init_repo and (args.require_init_adapter_revision or is_truthy(env.get("REQUIRE_INIT_ADAPTER_REVISION"))) and not init_revision:
        raise RuntimeError("INIT_ADAPTER_REPO requires INIT_ADAPTER_REVISION when REQUIRE_INIT_ADAPTER_REVISION=1")


def runtime_preflight(args: argparse.Namespace) -> None:
    disk_root = Path("/content") if Path("/content").exists() else ROOT
    total, used, free = shutil.disk_usage(disk_root)
    free_gib = free / (1024 ** 3)
    report: dict[str, Any] = {
        "run_mode": args.run_mode,
        "disk_root": str(disk_root),
        "disk_free_gib": round(free_gib, 3),
        "min_disk_free_gib": args.min_disk_free_gib,
        "accept_gpu_spend": bool(args.accept_gpu_spend),
    }
    if free_gib < args.min_disk_free_gib:
        report["status"] = "FAIL"
        print("KG1_V1243_PREFLIGHT_JSON", json.dumps(report, sort_keys=True), flush=True)
        raise RuntimeError(f"Not enough free disk: {free_gib:.2f} GiB < {args.min_disk_free_gib:.2f} GiB")

    if args.run_mode == "tokenize_dryrun":
        report["status"] = "PASS"
        print("KG1_V1243_PREFLIGHT_JSON", json.dumps(report, sort_keys=True), flush=True)
        return

    if not args.accept_gpu_spend:
        report["status"] = "FAIL"
        print("KG1_V1243_PREFLIGHT_JSON", json.dumps(report, sort_keys=True), flush=True)
        raise RuntimeError(
            f"{args.run_mode} is GPU-spend mode. Set KG1_ACCEPT_GPU_SPEND=1 only after tokenization gates pass."
        )

    try:
        import torch
        cuda_available = bool(torch.cuda.is_available())
        gpu_total_gib = (
            torch.cuda.get_device_properties(0).total_memory / (1024 ** 3)
            if cuda_available
            else 0.0
        )
    except Exception as exc:
        report["status"] = "FAIL"
        report["torch_probe_error"] = f"{type(exc).__name__}: {exc}"
        print("KG1_V1243_PREFLIGHT_JSON", json.dumps(report, sort_keys=True), flush=True)
        raise RuntimeError(f"Could not probe CUDA for {args.run_mode}: {exc}") from exc

    report["cuda_available"] = cuda_available
    report["gpu_total_gib"] = round(gpu_total_gib, 3)
    report["min_gpu_total_gib"] = args.min_gpu_total_gib
    if not cuda_available:
        report["status"] = "FAIL"
        print("KG1_V1243_PREFLIGHT_JSON", json.dumps(report, sort_keys=True), flush=True)
        raise RuntimeError(f"CUDA GPU is required for {args.run_mode}")
    if gpu_total_gib < args.min_gpu_total_gib:
        report["status"] = "FAIL"
        print("KG1_V1243_PREFLIGHT_JSON", json.dumps(report, sort_keys=True), flush=True)
        raise RuntimeError(
            f"GPU memory too small for safe Nemotron {args.run_mode}: "
            f"{gpu_total_gib:.2f} GiB < {args.min_gpu_total_gib:.2f} GiB"
        )
    try:
        from mamba_ssm.ops.triton.layernorm_gated import rmsnorm_fn  # noqa: F401
        report["mamba_ssm_rmsnorm"] = True
    except Exception as exc:
        report["status"] = "FAIL"
        report["mamba_ssm_rmsnorm"] = False
        report["mamba_ssm_error"] = f"{type(exc).__name__}: {exc}"
        print("KG1_V1243_PREFLIGHT_JSON", json.dumps(report, sort_keys=True), flush=True)
        raise RuntimeError(
            "mamba_ssm is required before Nemotron model load. "
            "Install mamba-ssm==2.3.1 with --no-build-isolation, then retry."
        ) from exc
    report["causal_conv1d"] = importlib.util.find_spec("causal_conv1d") is not None
    report["status"] = "PASS"
    print("KG1_V1243_PREFLIGHT_JSON", json.dumps(report, sort_keys=True), flush=True)


def print_env_summary(env: dict[str, str], run_id: str, args: argparse.Namespace) -> None:
    safe_keys = [
        "RUN_ID",
        "COMPUTE_PROVIDER",
        "DATA_FILE",
        "VAL_FILE",
        "OUTPUT_DIR",
        "OUTPUT_REPO",
        "DRY_RUN_VALIDATE_ONLY",
        "TOKENIZE_ONLY_DRY_RUN",
        "UPLOAD_TO_HF",
        "SCORE_CONTRACT_TARGET_ACCURACY",
        "SCORE_PROXY_EVAL_MAX_EXAMPLES",
        "FRIENDLY_REALTIME_LOGS",
        "KG1_LIVE_LOG_HF_REPO",
        "KG1_LIVE_LOG_HF_PATH",
        "REQUIRE_INIT_ADAPTER",
        "INIT_ADAPTER_DIR",
        "INIT_ADAPTER_REPO",
        "INIT_ADAPTER_REVISION",
    ]
    print("KG1_V1243_COLAB_LAUNCH_ENV_BEGIN", flush=True)
    print(json.dumps({key: env.get(key, "") for key in safe_keys}, indent=2, sort_keys=True), flush=True)
    print("KG1_V1243_COLAB_LAUNCH_ENV_END", flush=True)
    print(
        "KG1_V1243_COLAB_LAUNCH_DECISION "
        f"phase={args.phase} run_mode={args.run_mode} run_id={run_id} "
        f"target_accuracy={args.target_accuracy}",
        flush=True,
    )


def main() -> int:
    args = build_parser().parse_args()
    env_updates, run_id = build_env(args)
    print_env_summary(env_updates, run_id, args)
    if args.print_env_only:
        return 0

    child_env = os.environ.copy()
    child_env.update(env_updates)
    validate_initial_adapter_contract(child_env, args)
    runtime_preflight(args)
    if args.require_live_log_upload:
        token = child_env.get("HF_TOKEN") or child_env.get("HUGGINGFACE_HUB_TOKEN")
        if not args.live_log_repo:
            raise RuntimeError("live-log upload is required, but --live-log-repo is empty")
        if not token:
            raise RuntimeError("live-log upload is required, but HF_TOKEN/HUGGINGFACE_HUB_TOKEN is missing")

    command = [
        sys.executable,
        str(ROOT / "scripts" / "kg1_colab_realtime_runner.py"),
        "--upload-every",
        str(args.upload_every),
    ]
    if args.require_live_log_upload:
        command.append("--require-upload")
    if args.live_log_repo:
        command.extend(
            [
                "--hf-repo",
                args.live_log_repo,
                "--hf-path",
                child_env["KG1_LIVE_LOG_HF_PATH"],
                "--hf-status-path",
                child_env["KG1_LIVE_STATUS_HF_PATH"],
                "--hf-repo-type",
                args.live_log_repo_type,
            ]
        )
    else:
        command.append("--no-upload")
    command.extend(["--", sys.executable, str(ROOT / "scripts" / "hf_job_train_v90.py")])
    print("KG1_V1243_COLAB_COMMAND", " ".join(command), flush=True)
    return subprocess.call(command, env=child_env)


if __name__ == "__main__":
    raise SystemExit(main())
