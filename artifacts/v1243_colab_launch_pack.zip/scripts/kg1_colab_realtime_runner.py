#!/usr/bin/env python3
"""Run a KG1 Colab job while streaming logs to disk and optional Hugging Face."""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any

from kg1_live_log_common import empty_state, ingest_line, write_status


def default_log_dir() -> Path:
    if Path("/content").exists():
        return Path("/content/kg1_live_logs")
    return Path("artifacts/live_logs")


def env_float(name: str, default: float) -> float:
    value = os.environ.get(name)
    if value in (None, ""):
        return default
    return float(value)


def env_bool(name: str, default: bool = False) -> bool:
    value = os.environ.get(name)
    if value in (None, ""):
        return default
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    run_id = os.environ.get("RUN_ID", f"kg1_colab_{int(time.time())}")
    base = default_log_dir()
    parser.add_argument("--log-path", type=Path, default=base / f"{run_id}.log")
    parser.add_argument("--status-path", type=Path, default=base / f"{run_id}.status.json")
    parser.add_argument("--hf-repo", default=os.environ.get("KG1_LIVE_LOG_HF_REPO", ""))
    parser.add_argument("--hf-path", default=os.environ.get("KG1_LIVE_LOG_HF_PATH", f"colab/{run_id}/train.log"))
    parser.add_argument("--hf-status-path", default=os.environ.get("KG1_LIVE_STATUS_HF_PATH", f"colab/{run_id}/status.json"))
    parser.add_argument("--hf-repo-type", default=os.environ.get("KG1_LIVE_LOG_HF_REPO_TYPE", "dataset"))
    parser.add_argument("--upload-every", type=float, default=env_float("KG1_LIVE_LOG_UPLOAD_EVERY", 60.0))
    parser.add_argument("--no-upload", action="store_true")
    parser.add_argument("--require-upload", action="store_true", default=env_bool("KG1_REQUIRE_LIVE_LOG_UPLOAD"))
    parser.add_argument("command", nargs=argparse.REMAINDER)
    return parser


def normalize_command(raw: list[str]) -> list[str]:
    if raw and raw[0] == "--":
        raw = raw[1:]
    if raw:
        return raw
    return [sys.executable, "scripts/hf_job_train_v90.py"]


def upload_loop(
    *,
    stop_event: threading.Event,
    log_path: Path,
    status_path: Path,
    repo_id: str,
    path_in_repo: str,
    status_path_in_repo: str,
    repo_type: str,
    upload_every: float,
    strict_upload: bool,
    child_process: subprocess.Popen[str] | None,
    failure_reasons: list[str],
) -> None:
    def mark_failure(reason: str) -> None:
        failure_reasons.append(reason)
        print(f"KG1_LIVE_UPLOAD_FATAL {reason}", flush=True)
        if child_process is not None and child_process.poll() is None:
            print("KG1_LIVE_UPLOAD_FATAL terminating_child_process=true", flush=True)
            child_process.terminate()

    try:
        from huggingface_hub import HfApi
    except Exception as exc:
        message = f"reason=huggingface_hub_unavailable error={exc}"
        if strict_upload:
            mark_failure(message)
        else:
            print(f"KG1_LIVE_UPLOAD_DISABLED {message}", flush=True)
        return

    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_HUB_TOKEN")
    if not token:
        message = "reason=missing_HF_TOKEN"
        if strict_upload:
            mark_failure(message)
        else:
            print(f"KG1_LIVE_UPLOAD_DISABLED {message}", flush=True)
        return

    api = HfApi(token=token)
    try:
        api.create_repo(repo_id=repo_id, repo_type=repo_type, private=True, exist_ok=True, token=token)
    except Exception as exc:
        message = f"reason=create_repo_failed error={exc}"
        if strict_upload:
            mark_failure(message)
        else:
            print(f"KG1_LIVE_UPLOAD_DISABLED {message}", flush=True)
        return

    print(
        "KG1_LIVE_UPLOAD_ENABLED "
        f"repo={repo_id} repo_type={repo_type} log_path={path_in_repo} status_path={status_path_in_repo}",
        flush=True,
    )
    while not stop_event.wait(max(5.0, upload_every)):
        try:
            upload_snapshot(
                api=api,
                repo_id=repo_id,
                repo_type=repo_type,
                token=token,
                log_path=log_path,
                status_path=status_path,
                path_in_repo=path_in_repo,
                status_path_in_repo=status_path_in_repo,
                raise_on_error=strict_upload,
            )
        except Exception as exc:
            mark_failure(f"reason=periodic_upload_failed error={type(exc).__name__}: {exc}")
            stop_event.set()
            return
    try:
        upload_snapshot(
            api=api,
            repo_id=repo_id,
            repo_type=repo_type,
            token=token,
            log_path=log_path,
            status_path=status_path,
            path_in_repo=path_in_repo,
            status_path_in_repo=status_path_in_repo,
            raise_on_error=strict_upload,
        )
    except Exception as exc:
        mark_failure(f"reason=final_upload_failed error={type(exc).__name__}: {exc}")


def upload_snapshot(
    *,
    api: Any,
    repo_id: str,
    repo_type: str,
    token: str,
    log_path: Path,
    status_path: Path,
    path_in_repo: str,
    status_path_in_repo: str,
    raise_on_error: bool = False,
) -> None:
    errors: list[str] = []
    for local_path, remote_path in [(log_path, path_in_repo), (status_path, status_path_in_repo)]:
        if not local_path.exists():
            continue
        try:
            api.upload_file(
                path_or_fileobj=str(local_path),
                path_in_repo=remote_path,
                repo_id=repo_id,
                repo_type=repo_type,
                token=token,
                commit_message=f"kg1 live log update {remote_path}",
            )
            print(f"KG1_LIVE_UPLOAD_OK path={remote_path} bytes={local_path.stat().st_size}", flush=True)
        except Exception as exc:
            message = f"path={remote_path} error={type(exc).__name__}: {exc}"
            print(f"KG1_LIVE_UPLOAD_WARN {message}", flush=True)
            errors.append(message)
    if raise_on_error and errors:
        raise RuntimeError("required live-log upload failed: " + "; ".join(errors))


def require_upload_ready(
    *,
    log_path: Path,
    status_path: Path,
    repo_id: str,
    path_in_repo: str,
    status_path_in_repo: str,
    repo_type: str,
) -> None:
    try:
        from huggingface_hub import HfApi
    except Exception as exc:
        raise RuntimeError(f"live-log upload is required, but huggingface_hub is unavailable: {exc}") from exc

    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_HUB_TOKEN")
    if not token:
        raise RuntimeError("live-log upload is required, but HF_TOKEN/HUGGINGFACE_HUB_TOKEN is missing")
    if not repo_id:
        raise RuntimeError("live-log upload is required, but --hf-repo is empty")

    api = HfApi(token=token)
    try:
        api.create_repo(repo_id=repo_id, repo_type=repo_type, private=True, exist_ok=True, token=token)
    except Exception as exc:
        raise RuntimeError(f"live-log upload is required, but create_repo failed: {exc}") from exc

    upload_snapshot(
        api=api,
        repo_id=repo_id,
        repo_type=repo_type,
        token=token,
        log_path=log_path,
        status_path=status_path,
        path_in_repo=path_in_repo,
        status_path_in_repo=status_path_in_repo,
        raise_on_error=True,
    )
    print(
        "KG1_LIVE_UPLOAD_REQUIRED_OK "
        f"repo={repo_id} repo_type={repo_type} log_path={path_in_repo} status_path={status_path_in_repo}",
        flush=True,
    )


def final_upload_after_end(
    *,
    log_path: Path,
    status_path: Path,
    repo_id: str,
    path_in_repo: str,
    status_path_in_repo: str,
    repo_type: str,
    strict_upload: bool,
) -> list[str]:
    try:
        from huggingface_hub import HfApi
    except Exception as exc:
        message = f"reason=final_huggingface_hub_unavailable error={exc}"
        if strict_upload:
            print(f"KG1_LIVE_UPLOAD_FATAL {message}", flush=True)
        else:
            print(f"KG1_LIVE_UPLOAD_DISABLED {message}", flush=True)
        return [message] if strict_upload else []

    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_HUB_TOKEN")
    if not token:
        message = "reason=final_missing_HF_TOKEN"
        if strict_upload:
            print(f"KG1_LIVE_UPLOAD_FATAL {message}", flush=True)
        else:
            print(f"KG1_LIVE_UPLOAD_DISABLED {message}", flush=True)
        return [message] if strict_upload else []

    api = HfApi(token=token)
    try:
        api.create_repo(repo_id=repo_id, repo_type=repo_type, private=True, exist_ok=True, token=token)
        upload_snapshot(
            api=api,
            repo_id=repo_id,
            repo_type=repo_type,
            token=token,
            log_path=log_path,
            status_path=status_path,
            path_in_repo=path_in_repo,
            status_path_in_repo=status_path_in_repo,
            raise_on_error=strict_upload,
        )
    except Exception as exc:
        message = f"reason=final_upload_after_end_failed error={type(exc).__name__}: {exc}"
        if strict_upload:
            print(f"KG1_LIVE_UPLOAD_FATAL {message}", flush=True)
        else:
            print(f"KG1_LIVE_UPLOAD_WARN {message}", flush=True)
        return [message] if strict_upload else []
    return []


def main() -> int:
    args = build_parser().parse_args()
    command = normalize_command(args.command)
    args.log_path.parent.mkdir(parents=True, exist_ok=True)
    args.status_path.parent.mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env.setdefault("PYTHONUNBUFFERED", "1")
    env.setdefault("FRIENDLY_REALTIME_LOGS", "1")
    env.setdefault("FRIENDLY_LOG_SCORE_HINTS", "1")

    runner_start_lines = [
        "KG1_COLAB_REALTIME_RUNNER_START",
        f"command={' '.join(command)}",
        f"log_path={args.log_path}",
        f"status_path={args.status_path}",
    ]
    for line in runner_start_lines:
        print(line, flush=True)
    args.log_path.write_text("\n".join(runner_start_lines) + "\n", encoding="utf-8")

    state = empty_state()
    for line in runner_start_lines:
        ingest_line(state, line)
    write_status(args.status_path, state)

    upload_enabled = bool(args.hf_repo and not args.no_upload)
    if args.require_upload:
        if not upload_enabled:
            raise RuntimeError("live-log upload is required, but upload is disabled or --hf-repo is empty")
        require_upload_ready(
            log_path=args.log_path,
            status_path=args.status_path,
            repo_id=args.hf_repo,
            path_in_repo=args.hf_path,
            status_path_in_repo=args.hf_status_path,
            repo_type=args.hf_repo_type,
        )

    stop_event = threading.Event()
    uploader: threading.Thread | None = None
    upload_failure_reasons: list[str] = []
    if not upload_enabled:
        print("KG1_LIVE_UPLOAD_DISABLED reason=no_hf_repo_or_no_upload", flush=True)
    rc = 1
    with args.log_path.open("a", encoding="utf-8", buffering=1) as log:
        proc = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            env=env,
        )
        if upload_enabled:
            uploader = threading.Thread(
                target=upload_loop,
                kwargs={
                    "stop_event": stop_event,
                    "log_path": args.log_path,
                    "status_path": args.status_path,
                    "repo_id": args.hf_repo,
                    "path_in_repo": args.hf_path,
                    "status_path_in_repo": args.hf_status_path,
                    "repo_type": args.hf_repo_type,
                    "upload_every": args.upload_every,
                    "strict_upload": args.require_upload,
                    "child_process": proc,
                    "failure_reasons": upload_failure_reasons,
                },
                daemon=True,
            )
            uploader.start()
        assert proc.stdout is not None
        for line in proc.stdout:
            print(line, end="", flush=True)
            log.write(line)
            ingest_line(state, line)
            write_status(args.status_path, state)
        rc = proc.wait()

    stop_event.set()
    if uploader is not None:
        uploader.join(timeout=max(10.0, args.upload_every + 5.0))
    if upload_failure_reasons and rc == 0:
        rc = 88
        failure_line = "KG1_COLAB_REALTIME_RUNNER_UPLOAD_FAILURE return_code=88 " + "; ".join(upload_failure_reasons)
        with args.log_path.open("a", encoding="utf-8", buffering=1) as log:
            log.write(failure_line + "\n")
        ingest_line(state, failure_line)
        state["return_code"] = rc
        state["upload_failure_reasons"] = upload_failure_reasons
        write_status(args.status_path, state)
        print(failure_line, flush=True)
    end_line = f"KG1_COLAB_REALTIME_RUNNER_END return_code={rc}"
    with args.log_path.open("a", encoding="utf-8", buffering=1) as log:
        log.write(end_line + "\n")
    state["return_code"] = rc
    state["process_finished"] = True
    ingest_line(state, end_line)
    write_status(args.status_path, state)
    print(end_line, flush=True)
    if upload_enabled:
        final_upload_failures = final_upload_after_end(
            log_path=args.log_path,
            status_path=args.status_path,
            repo_id=args.hf_repo,
            path_in_repo=args.hf_path,
            status_path_in_repo=args.hf_status_path,
            repo_type=args.hf_repo_type,
            strict_upload=args.require_upload,
        )
        if final_upload_failures and rc == 0:
            rc = 88
            failure_line = (
                "KG1_COLAB_REALTIME_RUNNER_UPLOAD_FAILURE return_code=88 "
                + "; ".join(final_upload_failures)
            )
            with args.log_path.open("a", encoding="utf-8", buffering=1) as log:
                log.write(failure_line + "\n")
                log.write(f"KG1_COLAB_REALTIME_RUNNER_END return_code={rc}\n")
            ingest_line(state, failure_line)
            state["return_code"] = rc
            state["upload_failure_reasons"] = list(upload_failure_reasons) + final_upload_failures
            write_status(args.status_path, state)
            print(failure_line, flush=True)
            print(f"KG1_COLAB_REALTIME_RUNNER_END return_code={rc}", flush=True)
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
