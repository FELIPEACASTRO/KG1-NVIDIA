#!/usr/bin/env python3
"""Shared parser for KG1 real-time job logs."""

from __future__ import annotations

import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


TEACH_RE = re.compile(
    r"\[KG1-TEACH\]\[(?P<time>[^\]]+)\]\[(?P<stage>[^\]]+)\]\[(?P<status>[^\]]+)\]"
)
CONTRACT_RE = re.compile(
    r"KG1_SCORE_CONTRACT_STATUS=(?P<status>\w+).*?"
    r"errors=(?P<errors>\d+).*?"
    r"warnings=(?P<warnings>\d+).*?"
    r"target_correct_required=(?P<target>\d+).*?"
    r"additional_rows_required=(?P<additional>\d+)"
)
PROXY_RE = re.compile(
    r"KG1_SCORE_PROXY_STATUS=(?P<label>\S+)\s+"
    r"loss=(?P<loss>\S+)\s+"
    r"boxed_tail_loss=(?P<boxed_loss>\S+)\s+"
    r"boxed_tail_token_acc=(?P<boxed_acc>\S+)\s+"
    r"boxed_tail_exact_rate=(?P<boxed_exact>\S+)\s+"
    r"delta_loss=(?P<delta_loss>\S+)\s+"
    r"delta_boxed_tail_loss=(?P<delta_boxed_loss>\S+)\s+"
    r"delta_boxed_tail_exact_rate=(?P<delta_boxed_exact>\S+)"
)
STEP_RE = re.compile(
    r"step=(?P<step>\d+)/(?P<total>\d+)\s+lr=(?P<lr>\S+)\s+"
    r"train_loss=(?P<loss>\S+).*?(?P<mem>mem_alloc=.*|cuda_mem=unavailable)"
)
FATAL_RE = re.compile(
    r"Traceback|OutOfMemory|CUDA out of memory|RuntimeError|FloatingPointError|"
    r"Non-finite|ABORT:|score_contract_runtime_failed",
    re.IGNORECASE,
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def parse_float(value: object) -> float | None:
    try:
        parsed = float(str(value))
    except (TypeError, ValueError):
        return None
    if not math.isfinite(parsed):
        return None
    return parsed


def empty_state() -> dict[str, Any]:
    return {
        "schema_version": "kg1_live_log_health_v1",
        "updated_at_utc": utc_now(),
        "line_count": 0,
        "last_line": "",
        "last_teach": None,
        "stage_status": {},
        "score_contract": None,
        "score_proxy": None,
        "train_step": None,
        "alerts": [],
        "health": "BOOT",
        "health_reason": "waiting_for_log_lines",
    }


def append_alert(state: dict[str, Any], message: str) -> None:
    alerts = list(state.get("alerts") or [])
    alerts.append({"line": int(state.get("line_count") or 0), "message": message[:500]})
    state["alerts"] = alerts[-25:]


def ingest_line(state: dict[str, Any], line: str) -> dict[str, Any]:
    clean = line.rstrip("\n")
    state["line_count"] = int(state.get("line_count") or 0) + 1
    state["last_line"] = clean[-1000:]
    state["updated_at_utc"] = utc_now()

    match = TEACH_RE.search(clean)
    if match:
        event = match.groupdict()
        state["last_teach"] = event
        stage_status = dict(state.get("stage_status") or {})
        stage_status[event["stage"]] = event["status"]
        state["stage_status"] = stage_status
        if event["stage"] == "ABORT" or event["status"] == "STOP":
            append_alert(state, clean)

    match = CONTRACT_RE.search(clean)
    if match:
        groups = match.groupdict()
        state["score_contract"] = {
            "status": groups["status"],
            "errors": int(groups["errors"]),
            "warnings": int(groups["warnings"]),
            "target_correct_required": int(groups["target"]),
            "additional_rows_required": int(groups["additional"]),
        }
        if groups["status"] != "PASS":
            append_alert(state, clean)

    match = PROXY_RE.search(clean)
    if match:
        groups = match.groupdict()
        state["score_proxy"] = {
            "label": groups["label"],
            "loss": parse_float(groups["loss"]),
            "boxed_tail_loss": parse_float(groups["boxed_loss"]),
            "boxed_tail_token_accuracy": parse_float(groups["boxed_acc"]),
            "boxed_tail_exact_rate": parse_float(groups["boxed_exact"]),
            "delta_loss": parse_float(groups["delta_loss"]),
            "delta_boxed_tail_loss": parse_float(groups["delta_boxed_loss"]),
            "delta_boxed_tail_exact_rate": parse_float(groups["delta_boxed_exact"]),
        }

    match = STEP_RE.search(clean)
    if match:
        groups = match.groupdict()
        state["train_step"] = {
            "step": int(groups["step"]),
            "total": int(groups["total"]),
            "lr": groups["lr"],
            "train_loss": parse_float(groups["loss"]),
            "memory": groups["mem"],
        }

    if FATAL_RE.search(clean):
        append_alert(state, clean)

    update_health(state)
    return state


def parse_text(text: str) -> dict[str, Any]:
    state = empty_state()
    for line in text.splitlines():
        ingest_line(state, line)
    return state


def update_health(state: dict[str, Any]) -> None:
    stage_status = state.get("stage_status") or {}
    contract = state.get("score_contract") or {}
    proxy = state.get("score_proxy") or {}
    alerts = state.get("alerts") or []

    if alerts:
        state["health"] = "STOP"
        state["health_reason"] = str(alerts[-1].get("message", "alert"))
        return
    if contract.get("status") == "FAIL":
        state["health"] = "STOP"
        state["health_reason"] = "score_contract_failed"
        return
    if stage_status.get("SCORE_CONTRACT") == "STOP":
        state["health"] = "STOP"
        state["health_reason"] = "score_contract_teach_stop"
        return
    if stage_status.get("SCORE_PROXY") == "STOP":
        state["health"] = "STOP"
        state["health_reason"] = "score_proxy_stop"
        return
    if stage_status.get("SCORE_PROXY") == "RISK":
        state["health"] = "RISK"
        state["health_reason"] = "score_proxy_risk"
        return

    boxed_loss_delta = parse_float(proxy.get("delta_boxed_tail_loss"))
    boxed_exact_delta = parse_float(proxy.get("delta_boxed_tail_exact_rate"))
    if boxed_loss_delta is not None and boxed_loss_delta >= 0 and boxed_exact_delta is not None and boxed_exact_delta <= 0:
        state["health"] = "RISK"
        state["health_reason"] = "boxed_tail_not_improving"
        return

    if contract.get("status") == "PASS" and stage_status.get("SCORE_PROXY") == "OK":
        state["health"] = "OK"
        state["health_reason"] = "contract_passed_and_proxy_ok"
        return
    if contract.get("status") == "PASS":
        state["health"] = "WATCH"
        state["health_reason"] = "contract_passed_waiting_for_proxy"
        return

    state["health"] = "BOOT"
    state["health_reason"] = "waiting_for_contract"


def target_math(target_accuracy: float, full_rows: int, baseline_correct: int) -> dict[str, Any]:
    required = int(math.ceil(float(target_accuracy) * int(full_rows)))
    return {
        "target_accuracy": target_accuracy,
        "full_rows": full_rows,
        "baseline_correct": baseline_correct,
        "baseline_accuracy": baseline_correct / max(1, full_rows),
        "target_correct_required": required,
        "additional_rows_required": max(0, required - baseline_correct),
    }


def render_dashboard(
    state: dict[str, Any],
    *,
    target_accuracy: float,
    full_rows: int = 947,
    baseline_correct: int = 823,
) -> str:
    math_state = target_math(target_accuracy, full_rows, baseline_correct)
    contract = state.get("score_contract") or {}
    proxy = state.get("score_proxy") or {}
    step = state.get("train_step") or {}
    alerts = state.get("alerts") or []
    lines = [
        "=" * 78,
        f"KG1 LIVE COLAB MONITOR | health={state.get('health')} | reason={state.get('health_reason')}",
        "=" * 78,
        f"updated_at_utc: {state.get('updated_at_utc')}",
        f"lines_seen: {state.get('line_count')}",
        f"target_math: target={target_accuracy:.4f} required={math_state['target_correct_required']}/{full_rows} "
        f"gain_needed=+{math_state['additional_rows_required']} from {baseline_correct}/{full_rows}",
        "",
        "score_contract:",
        f"  status={contract.get('status', 'missing')} errors={contract.get('errors', '?')} "
        f"warnings={contract.get('warnings', '?')} additional_rows={contract.get('additional_rows_required', '?')}",
        "train_step:",
        f"  step={step.get('step', '?')}/{step.get('total', '?')} train_loss={step.get('train_loss', '?')} "
        f"lr={step.get('lr', '?')} mem={step.get('memory', '?')}",
        "score_proxy:",
        f"  label={proxy.get('label', 'missing')} loss={proxy.get('loss', '?')} "
        f"boxed_loss={proxy.get('boxed_tail_loss', '?')} boxed_acc={proxy.get('boxed_tail_token_accuracy', '?')} "
        f"boxed_exact={proxy.get('boxed_tail_exact_rate', '?')}",
        f"  delta_loss={proxy.get('delta_loss', '?')} "
        f"delta_boxed_loss={proxy.get('delta_boxed_tail_loss', '?')} "
        f"delta_boxed_exact={proxy.get('delta_boxed_tail_exact_rate', '?')}",
        "last_teach:",
        f"  {state.get('last_teach')}",
    ]
    if alerts:
        lines.append("alerts:")
        for alert in alerts[-5:]:
            lines.append(f"  line {alert.get('line')}: {alert.get('message')}")
    else:
        lines.append("alerts: none")
    return "\n".join(lines)


def write_status(path: Path, state: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state, indent=2, sort_keys=True), encoding="utf-8")

