# KG1 V1243 Colab Launch Pack

This pack contains the minimal scripts and V1243 data artifacts needed to run
the bit/equation specialist training path with real-time logs.

## Colab Setup

Upload and unzip this pack in Colab, then run:

```bash
pip install -q -r requirements_v1243_colab.txt
```

Tokenize-only dry run:

```bash
python scripts/kg1_colab_v1243_launcher.py   --phase bit_specialist   --run-mode tokenize_dryrun   --target-accuracy 0.98   --live-log-repo "$KG1_LIVE_LOG_HF_REPO"   --require-live-log-upload
```

GPU model-load dry run:

```bash
export KG1_ACCEPT_GPU_SPEND=1
export INIT_ADAPTER_REPO="owner/baseline-adapter-repo"
export INIT_ADAPTER_REVISION="pinned-commit-sha"
python scripts/kg1_colab_v1243_launcher.py   --phase bit_specialist   --run-mode model_dryrun   --accept-gpu-spend   --target-accuracy 0.98   --live-log-repo "$KG1_LIVE_LOG_HF_REPO"   --require-live-log-upload
```

Real train, only after gates and explicit decision:

```bash
export KG1_ACCEPT_GPU_SPEND=1
export INIT_ADAPTER_REPO="owner/baseline-adapter-repo"
export INIT_ADAPTER_REVISION="pinned-commit-sha"
python scripts/kg1_colab_v1243_launcher.py   --phase bit_specialist   --run-mode real_train   --allow-real-train   --accept-gpu-spend   --target-accuracy 0.98   --live-log-repo "$KG1_LIVE_LOG_HF_REPO"   --require-live-log-upload   --output-repo "$OUTPUT_REPO"
```

Do not submit anything from this pack directly. Score claims still require
vLLM greedy raw_output generation and V1241 full947 gate.
