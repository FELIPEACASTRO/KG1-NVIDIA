# KG1 V1243 Colab Launch Pack

This pack contains the minimal scripts and V1243 data artifacts needed to run
the bit/equation specialist training path with real-time logs.

## Colab Setup

Upload and unzip this pack in Colab, then run:

```bash
pip install -q -U accelerate bitsandbytes hf_transfer huggingface_hub peft safetensors transformers
```

Tokenize-only dry run:

```bash
python scripts/kg1_colab_v1243_launcher.py   --phase bit_specialist   --run-mode tokenize_dryrun   --target-accuracy 0.98   --live-log-repo "$KG1_LIVE_LOG_HF_REPO"
```

GPU model-load dry run:

```bash
python scripts/kg1_colab_v1243_launcher.py   --phase bit_specialist   --run-mode model_dryrun   --target-accuracy 0.98   --live-log-repo "$KG1_LIVE_LOG_HF_REPO"
```

Real train, only after gates and explicit decision:

```bash
python scripts/kg1_colab_v1243_launcher.py   --phase bit_specialist   --run-mode real_train   --allow-real-train   --target-accuracy 0.98   --live-log-repo "$KG1_LIVE_LOG_HF_REPO"   --output-repo "$OUTPUT_REPO"
```

Do not submit anything from this pack directly. Score claims still require
vLLM greedy raw_output generation and V1241 full947 gate.
