# KG1 V1243 Solver-to-LoRA GRAFT

Generated UTC: `2026-06-13T18:28:37+00:00`

## Verdict

- Decision: `pass_v1243_cpu_dataset_graft_no_gpu_no_submit`
- This is CPU-only data preparation. It does not authorize GPU, package, or Kaggle submission.

## Algorithm

`GRAFT` = Gate-verified Replay Answer-Focused Transfer.

The method builds family-specialist LoRA training packs from V1240 solver-verified rows:

- bit specialist: bit rows plus protected replay.
- equation specialist: equation rows plus protected replay.
- micro consolidation: bit + equation + protected replay, only after specialists pass gates.
- validation: V1240 val170 held out for raw-output gate checks.

Targets stay short and score-facing: one terminal boxed answer. The intended trainer
contract is completion-only loss with priority on the final boxed payload. The generated
HF preview locks `TOKENIZE_ONLY_DRY_RUN=1`, `REQUIRE_OFFSET_MASK=1`,
`REQUIRE_BOXED_PAYLOAD_WEIGHT=1`, `BOXED_PAYLOAD_LOSS_WEIGHT=5.0`,
the runtime score-contract indicator in hard-fail mode, and score-proxy
evaluation logs for the boxed answer tail. Human-friendly `KG1-TEACH`
logs stay enabled for real-time job monitoring.

## Outputs

- Bit specialist train: `C:\Users\davis\Workspace\KG1 -NVIDIA\artifacts\v1243_solver_to_lora_graft\v1243_bit_specialist_train.jsonl`
- Equation specialist train: `C:\Users\davis\Workspace\KG1 -NVIDIA\artifacts\v1243_solver_to_lora_graft\v1243_equation_specialist_train.jsonl`
- Protected replay train: `C:\Users\davis\Workspace\KG1 -NVIDIA\artifacts\v1243_solver_to_lora_graft\v1243_protected_replay_train.jsonl`
- Micro consolidation train: `C:\Users\davis\Workspace\KG1 -NVIDIA\artifacts\v1243_solver_to_lora_graft\v1243_micro_consolidation_train.jsonl`
- Val170 holdout: `C:\Users\davis\Workspace\KG1 -NVIDIA\artifacts\v1243_solver_to_lora_graft\v1243_val170.jsonl`
- HF env preview: `C:\Users\davis\Workspace\KG1 -NVIDIA\artifacts\v1243_solver_to_lora_graft\v1243_hf_env_preview.json`

## Trainer Contract

- The first validation run is tokenize-only and cannot upload to HF.
- Dataset hashes and minimum row counts are pinned in the env preview.
- `LORA_TARGET_MODULES` and `TRAINABLE_LORA_MODULES` are both locked to `down_proj,in_proj,k_proj,o_proj,q_proj,up_proj,v_proj`.
- Row-level sampling weights must be preserved through tokenization before weighted replacement sampling.
- The trainer must boost final boxed-payload tokens before any real GPU run.
- Run `python scripts/kg1_v1243_graft_trainer_contract_gate.py` after regeneration.

## Mandatory Gate Commands

Run these only after real generation CSVs exist. They require raw_output columns.

```powershell
python C:\Users\davis\Workspace\KG1 -NVIDIA\scripts\kg1_v1241_bit_equation_transfer_gate.py --profile tiny --solution-csv C:\Users\davis\Workspace\KG1 -NVIDIA\artifacts\v1241_bit_equation_real_transfer_gate\v1241_tiny_bit_equation_probe_solution.csv --baseline-predictions path\to\baseline_predictions_with_raw_output.csv --candidate-predictions path\to\candidate_predictions_with_raw_output.csv
python C:\Users\davis\Workspace\KG1 -NVIDIA\scripts\kg1_v1241_bit_equation_transfer_gate.py --profile val170 --solution-csv C:\Users\davis\Workspace\KG1 -NVIDIA\artifacts\v1241_bit_equation_real_transfer_gate\v1241_v1240_val170_solution.csv --baseline-predictions path\to\baseline_predictions_with_raw_output.csv --candidate-predictions path\to\candidate_predictions_with_raw_output.csv
python C:\Users\davis\Workspace\KG1 -NVIDIA\scripts\kg1_v1241_bit_equation_transfer_gate.py --profile full947_089 --solution-csv path\to\full947_solution.csv --baseline-predictions path\to\baseline_predictions_with_raw_output.csv --candidate-predictions path\to\candidate_predictions_with_raw_output.csv
```

## Do Not Do

- Do not use this artifact as score proof.
- Do not launch paid GPU until dry-run/tokenization/objective gates pass.
- Do not submit unless V1241 full947 passes with raw outputs.
- Do not train on FASE5/s140/fase5_mix.
